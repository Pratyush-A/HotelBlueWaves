import express from "express";
import Guest from "../models/Guest.js";
import cloudinary from "../lib/cloudinary.js";

const router = express.Router();

// Create a new guest
router.post("/", async (req, res) => {
  try {
    const { name, phone, idProof } = req.body;
    if (!name || !phone || !idProof) {
      return res.status(400).json({ message: "All fields required" });
    }

    const uploadResponse = await cloudinary.uploader.upload(idProof);
    const guest = new Guest({
      name,
      phone,
      idProofUrl: uploadResponse.secure_url,
    });

    await guest.save();
    res.status(201).json(guest);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🔥 Add this GET route to fetch all guests
router.get("/", async (req, res) => {
  try {
    const guests = await Guest.find();
    res.status(200).json(guests);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch guests" });
  }
});

export default router;
